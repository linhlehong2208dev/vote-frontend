import { useCallback, useEffect, useState } from "react";
import { api, type GameInfo } from "../lib/api";

const STATUS: Record<string, { label: string; className: string }> = {
  draft: { label: "Bản nháp", className: "bg-white/10 text-white/70" },
  lobby: { label: "Lobby", className: "bg-sky/15 text-sky" },
  active: { label: "Đang live", className: "bg-emerald/15 text-emerald" },
  closed: { label: "Đã kết thúc", className: "bg-white/10 text-white/45" },
};

export function AdminHomePage({ onCreate, onOpen }: { onCreate: () => void; onOpen: (id: string) => void }) {
  const [games, setGames] = useState<GameInfo[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setGames((current) => current ?? null);
      const result = await api.listGames();
      setGames(result.games);
      setError(null);
    } catch (err: any) {
      setError(err?.message ?? "Không thể tải danh sách Game.");
      setGames([]);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  return (
    <div className="min-h-screen bg-stage-950 text-white">
      <header className="sticky top-0 z-20 border-b border-white/10 bg-stage-950/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4 md:px-8">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.22em] text-amber">VOTE STUDIO</p>
            <h1 className="mt-1 font-display text-xl font-extrabold tracking-tight md:text-2xl">My Games</h1>
          </div>
          <button onClick={onCreate} className="rounded-2xl bg-amber px-4 py-3 text-sm font-extrabold text-stage-950 shadow-tile transition hover:-translate-y-0.5 active:translate-y-1 active:shadow-tile-active">
            + Tạo Game
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-8 md:px-8 md:py-10">
        <section className="mb-8 grid gap-4 md:grid-cols-[1.6fr_1fr]">
          <div className="rounded-[28px] border border-white/10 bg-gradient-to-br from-stage-800 to-stage-900 p-6 md:p-8">
            <p className="text-sm font-semibold text-white/55">QUIZ & LIVE VOTING</p>
            <h2 className="mt-3 max-w-xl font-display text-3xl font-extrabold leading-tight md:text-5xl">
              Tạo một Game. Chạy nhiều câu hỏi. Một PIN duy nhất.
            </h2>
            <p className="mt-4 max-w-2xl text-sm leading-6 text-white/55 md:text-base">
              Thiết kế bộ câu hỏi, chọn visual và sau đó đưa Game lên màn hình lớn cho người chơi tham gia bằng QR hoặc Game PIN.
            </p>
            <button onClick={onCreate} className="mt-7 rounded-2xl bg-white px-5 py-3 font-display text-sm font-extrabold text-stage-950 transition hover:scale-[1.02]">
              Bắt đầu tạo Game →
            </button>
          </div>
          <div className="rounded-[28px] border border-white/10 bg-stage-800 p-6">
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/40">V2 foundation</p>
            <div className="mt-5 space-y-4">
              {[["01", "Game PIN", "Một mã cho toàn bộ Game"], ["02", "Multi-question", "Nhiều câu hỏi trong cùng một lobby"], ["03", "Presentation", "Sẵn sàng cho màn hình TV / projector"]].map(([n, title, desc]) => (
                <div key={n} className="flex gap-4">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/8 text-xs font-extrabold text-amber">{n}</span>
                  <div><p className="font-display font-bold">{title}</p><p className="mt-0.5 text-xs leading-5 text-white/40">{desc}</p></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <div className="mb-4 flex items-end justify-between">
          <div><h2 className="font-display text-2xl font-extrabold">Game của bạn</h2><p className="mt-1 text-sm text-white/40">Quản lý các bộ câu hỏi và phiên live.</p></div>
          <button onClick={() => void load()} className="text-xs font-bold text-white/45 hover:text-white">↻ Làm mới</button>
        </div>

        {error && <div className="mb-4 rounded-2xl border border-coral/30 bg-coral/10 p-4 text-sm text-coral">{error}</div>}
        {games === null && <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{[1,2,3].map((x) => <div key={x} className="h-48 animate-pulse rounded-[24px] bg-white/5" />)}</div>}
        {games?.length === 0 && (
          <div className="rounded-[28px] border border-dashed border-white/15 bg-white/[0.02] px-6 py-16 text-center">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-amber/15 text-3xl">＋</div>
            <h3 className="mt-5 font-display text-xl font-extrabold">Chưa có Game nào</h3>
            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-white/40">Tạo Game đầu tiên và thêm nhiều câu hỏi vào cùng một bộ.</p>
            <button onClick={onCreate} className="mt-6 rounded-2xl bg-amber px-5 py-3 text-sm font-extrabold text-stage-950">Tạo Game đầu tiên</button>
          </div>
        )}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {games?.map((game) => {
            const status = STATUS[game.status] ?? STATUS.draft;
            return <button key={game.id} onClick={() => onOpen(game.id)} className="group overflow-hidden rounded-[24px] border border-white/10 bg-stage-800 text-left transition hover:-translate-y-1 hover:border-white/20 hover:shadow-2xl">
              <div className="relative h-32 overflow-hidden bg-gradient-to-br from-stage-700 to-stage-900">
                {game.cover_url && <img src={game.cover_url} alt="" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />}
                <div className="absolute inset-0 bg-gradient-to-t from-stage-950/80 to-transparent" />
                <span className={`absolute left-4 top-4 rounded-full px-3 py-1 text-[11px] font-extrabold ${status.className}`}>{status.label}</span>
                <span className="absolute bottom-3 right-4 rounded-lg bg-black/30 px-2.5 py-1 font-mono text-xs font-bold tracking-[0.18em] text-white">{game.pin}</span>
              </div>
              <div className="p-5"><h3 className="line-clamp-2 font-display text-lg font-extrabold">{game.title}</h3><p className="mt-2 text-xs text-white/40">{new Date(game.created_at).toLocaleDateString("vi-VN")} · Mở để quản lý</p></div>
            </button>;
          })}
        </div>
      </main>
    </div>
  );
}
